import { useState } from "react";
import styles from "./Community.module.css";
import Navbar from "../../Navbar/Navbar";
import LeftSidebar from "./Rightsidebar/RightSidebar";
import Feed from "./Feed/Feed";
import RightSidebar from "./RightSidebar/RightSidebar";
import { useAuth } from "../../../context/AuthContext";

export default function Community() {
  const [activeNav, setActiveNav] = useState("community");
  const { user } = useAuth();

  // Guard — shouldn't render until auth is resolved
  if (!user) return null;

  return (
    <div className={styles.root}>
      <Navbar />
      <div className={styles.layout}>
        <LeftSidebar activeNav={activeNav} onNavChange={setActiveNav} />

        {/* Only this column scrolls */}
        <div className={styles.feedCol}>
          <Feed />
        </div>

        <RightSidebar />
      </div>
    </div>
  );
}
