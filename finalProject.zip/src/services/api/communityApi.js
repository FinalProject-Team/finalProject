// ═══════════════════════════════════════════════════════
//  communityApi.js — caching wrapper over service layer
//  localStorage cache (5-min TTL) per key.
//  TODO: When backend is live, remove cache wrappers and
//        call services directly with axios interceptors.
// ═══════════════════════════════════════════════════════

import {
  fetchPosts,
} from "../services/postService";
import {
  fetchLeaderboard,
} from "../services/communityService";

const TTL = 5 * 60 * 1000; // 5 minutes

function getCache(key) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const { data, ts } = JSON.parse(raw);
    if (Date.now() - ts > TTL) { localStorage.removeItem(key); return null; }
    return data;
  } catch { return null; }
}

function setCache(key, data) {
  try { localStorage.setItem(key, JSON.stringify({ data, ts: Date.now() })); } catch {}
}

export async function getPosts() {
  // NOTE: Posts come from PostsContext (live state), not cache
  // This is kept for SSR/initial hydration pattern
  return fetchPosts();
}



export async function getLeaderboard() {
  const c = getCache("ct_leaderboard");
  if (c) return c;
  const d = await fetchLeaderboard();
  setCache("ct_leaderboard", d);
  return d;
}





export function invalidateCache() {
  ["ct_trending","ct_leaderboard","ct_events","ct_suggested"].forEach(
    (k) => localStorage.removeItem(k)
  );
}
